RODAPÉ
<footer class="bg-dark p-5 text-light">
    <div claas="container">
        <small>
            Aula de PHP Orientado a Objetos com MVC. Versão <?= APP_VERSAO?> 
            <div class="border-top mt-3">
                &COPY; 2026 - <?= date('Y')?> IFRO - Guajará-Mirim / Informática - Programação Web
            </div>
        </small>
    </div>
</footer>