<div class="col-md-8 mx-auto p-5">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= URL ?>/posts">Posts</a></li>
            <li class="breadcrumb-item active" aria-current="page">Editar</li>
        </ol>
    </nav>
    <div class="card">
        <div class="card-header bg-secondary text-white">
            Editar Posts
        </div>
        <div class="card-body bg-ligth">
            <form name="edipost method=post" action="<?= URL ?>/posts/editar<?=$dados['id']?>" class="mt-4">
                <div class="form-group">
                    <label for="titulo"> Título: <sup class="text-danger">*</sup></label>
                    <input type="text" name="titulo" id="titulo" value="<?= $dados['titulo'] ?>" class="form-control<?= $dado['titulo_erro'] ? 'is-invalid' : '' ?> ">
                    <div class="invalid-feedback">
                        <?= $dados['titulo_erro'] ?>
                    </div>
                    <div class="form-group">
                        <label form="texto">Texto: <sup class="text-danger">*</sup></label>
                        <textarea name="texto" id="texto" class="form-control <?= $dados['texto_erro'] ? 'is-invalid' : '' ?>" rows="5"><?= $dados['texto'] ?></textarea>
                        <div class="invalid-feedback">
                            <?= $dados['texto_erro'] ?>
                        </div>
                        <input type="submit" value="Atualizar Post" class="btn-info btn-block">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>