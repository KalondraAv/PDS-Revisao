<?php
define('APP', dirname(__FILE__));
define('URL', 'http://localhost/noticias');
define('APP_NOME', "Site de Notícias");
//outera forma de declarar constantes
const APP_VERSAO = '1.0.0';
?>